payroll-1.0

PREREQUEST 
----------

1. JDK 15
2. PostgreSQL 13

INSTALLATION
------------

1. Unzip payroll.zip to a directory say c:\project and
   now your PAYROLL_HOME is c:\project\payroll.
2. cd PAYROLL_HOME\config and update database url, user and
   password in payroll.properties.
3. cd PAYROLL_HOME\bin and modifiy PAYROLL_HOME in payrolltest.cmd
   and save.
4. To verify your installation , please run payrolltest.cmd.

payroll.zip content
-------------------

    c:\Project\payroll
    c:\Project\payroll\bin
    c:\Project\payroll\config
    c:\Project\payroll\db
    c:\Project\payroll\docs
    c:\Project\payroll\lib