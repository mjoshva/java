package com.infinira.payroll;

import com.infinira.payroll.model.Employee;
import com.infinira.payroll.model.EmployeeStatus;
import com.infinira.payroll.util.ResourceUtil;
import com.infinira.payroll.util.PayrollUtil;
import com.infinira.payroll.service.PayrollInterface;
import com.infinira.payroll.service.PayrollService;
import com.infinira.payroll.util.PayrollException;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.File;
import java.util.List;
import java.text.SimpleDateFormat;  

public class PayrollTest {
    private static final double MAX_SIZE_IN_KB = 5500;
    private static final int ONE_KB = 1024;
    
    private static boolean checkPhotoSize(File photo) {
        return ((double) photo.length() / ONE_KB) < MAX_SIZE_IN_KB;
    }
    
    private static byte[] readBytes(File file, FileInputStream fis) {
        BufferedInputStream bufferedInputStream = null;
        try {
            byte[] data = new byte[(int) file.length()];
            bufferedInputStream = new BufferedInputStream(fis);
            bufferedInputStream.read(data,0,data.length);
            return data;
        } catch (Throwable th) {
            throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00010", file), th);
        } finally {
            if (bufferedInputStream != null) {
                try {
                    bufferedInputStream.close();
                } catch (Throwable th) {}
            }
        }
    }
    
    private Employee prepareEmployee() {
        Employee emp = new Employee("John", "Akhen", "ESDFRE5478", "154786541895");
        FileInputStream empPhoto= null;
        try {
            emp.setFatherName("Robert");
            
            emp.setAddressLine1("no:4 rr street");
            emp.setAddressLine2("kk nagar");
            emp.setCity("Trichy");
            emp.setState("Tamil Nadu");
            emp.setCountry("India");
            emp.setZipCode("620000");
            
            emp.setGender("m");
            emp.setDOB(new SimpleDateFormat("dd/MM/yyyy").parse("14/05/1994"));
            emp.setMaritalStatus("s");
            emp.setPhone("+91 9898565698");
            emp.setEmail("john@gmail.com");
            
            emp.setBloodGroup("O+");   
            emp.setDOJ(new SimpleDateFormat("dd/MM/yyyy").parse("21/12/2020"));
            
            File photoPath = new File("D:/photo5MB.jpg");
            if (checkPhotoSize(photoPath)) {
                empPhoto = new FileInputStream(photoPath);
            } else {
                throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00002", photoPath));
            }
            emp.setPhoto(readBytes(photoPath, empPhoto));
            emp.setStatus(EmployeeStatus.ACTIVE);
            return emp;
        } catch (Throwable th) {
            throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00001", emp.getFirstName()), th);
        } finally {
            if (empPhoto != null) {
                try {
                    empPhoto.close();
                } catch (Throwable th) {}
            }
        }
    }
    
    private int createEmployee(Employee emp) {        
        return new PayrollService().createEmployee(emp);
    }
    
    private void updateEmployee(int empId, Employee emp) {
        FileInputStream empPhoto = null;
        try {
            emp.setId(empId);
            emp.setFirstName("Helen");
            emp.setLastName("Mary");
            emp.setFatherName("Selvam");
            
            emp.setAddressLine1("no: 10, mm streat");
            emp.setAddressLine2("anna nagar");
            emp.setCity("Madurai");
            emp.setState("Tamil Nadu");
            emp.setCountry("India");
            emp.setZipCode("625001");
            
            emp.setGender("f");
            emp.setDOB(new SimpleDateFormat("dd/MM/yyyy").parse("25/06/1992"));
            emp.setMaritalStatus("m");
            emp.setPhone("+91 6589652356");
            emp.setEmail("helen@gmail.com");
        
            emp.setIncomeTaxId("EPSMKF5896");
            emp.setNationalId("587462589452");
            
            emp.setBloodGroup("AB+");   
            emp.setDOJ(new SimpleDateFormat("dd/MM/yyyy").parse("02/01/2010"));
            
            File photoPath = new File("D:/photo2.jpg");
            if(checkPhotoSize(photoPath)) {
                empPhoto = new FileInputStream(photoPath);
            } else {
                throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00002", photoPath));
            }
            emp.setPhoto(readBytes(photoPath, empPhoto));
            emp.setStatus(EmployeeStatus.ACTIVE);
            
            new PayrollService().updateEmployee(emp);            
        } catch (Throwable th) {
            throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00005", emp.getId()), th);
        } finally {
            if (empPhoto != null) {
                try {
                    empPhoto.close();
                } catch (Throwable th) {}
            }
        }
    }
    
    private Employee getEmployeeById(int empId) {
        return new PayrollService().getEmployeeById(empId);
    }
    
    private List<Employee> getAllEmployee() {
        return new PayrollService().getAllEmployee();
    }
    
    private void deleteEmployee(int empId) {
        new PayrollService().deleteEmployee(empId);
    }
    
    public static void main(String[] args) {
        PayrollUtil.createSchema();
        
        PayrollTest payrollTest = new PayrollTest();
        
        int empId = payrollTest.createEmployee(payrollTest.prepareEmployee());

        payrollTest.updateEmployee(empId, payrollTest.prepareEmployee());
        
        Employee getEmp = payrollTest.getEmployeeById(empId);
        
        List<Employee> getAllEmp = payrollTest.getAllEmployee();
        
        payrollTest.deleteEmployee(empId);
    }
}