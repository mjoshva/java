package com.infinira.payroll.util;

public class PayrollException extends RuntimeException{
    
    public PayrollException(String message) {
        super(message);
    }
    
    public PayrollException(String message, Throwable th) {
        super(message, th);
    }
}