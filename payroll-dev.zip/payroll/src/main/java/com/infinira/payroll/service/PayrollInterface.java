package com.infinira.payroll.service;

import com.infinira.payroll.model.Employee;
import java.util.List;

public interface PayrollInterface {
    
    public int createEmployee(Employee emp);
    
    public void updateEmployee(Employee emp);
    
    public Employee getEmployeeById(int empId);
    
    public List<Employee> getAllEmployee();
    
    public void deleteEmployee(int empId);
}