package com.infinira.payroll.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.DatabaseMetaData;
import java.util.Properties;
import java.io.InputStream;
import java.text.MessageFormat;

public class DbUtil {
    private static volatile DbUtil instance = null;
    
    private static final String CONFIG_FILE_NAME = "payroll.properties";
    private static final String DB_URL = "db.url";
    private static final String DB_USER = "db.user";
    private static final String DB_PASSWORD = "db.password";   
    
    private static String url;
    private static String user;
    private static String password; 

    private static final String TABLE = "table";
    private static final String SQL_FILE = "sql file";
    
    private DbUtil() {
        init();
    }
    
    public static DbUtil getInstance() {
        if (instance == null) {
            synchronized(DbUtil.class) {
                if (instance == null) {
                    instance = new DbUtil();
                }
            }
        }           
        return instance;
    }
    
    private void init() {
        InputStream in = null;
        try {
            in = ClassLoader.getSystemClassLoader().getResourceAsStream(CONFIG_FILE_NAME);
            Properties prop = new Properties();
            prop.load(in);
            
            url = prop.getProperty(DB_URL);
            user = prop.getProperty(DB_USER);
            password = prop.getProperty(DB_PASSWORD);   
        } catch(Throwable th) {
            throw new RuntimeException(getMessage(PROPERTIES_FAILED, CONFIG_FILE_NAME), th);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch(Throwable th) {}
            }
        }
    }
    
    public Connection getConnection() {
        try {           
            Connection conn = DriverManager.getConnection(url, user, password);
            return conn;
        } catch(Throwable th) {
            throw new RuntimeException(getMessage(CONNECTION_FAILED, url), th);
        }
    }
    
    public boolean isTableExist(String tableName) {
        isValid(TABLE, tableName);
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = DbUtil.getInstance().getConnection();
            DatabaseMetaData m = conn.getMetaData();
            rs = m.getTables(null, null, tableName, null);
           
            return rs.next() ? true : false;      
        } catch(Throwable th) {
            throw new RuntimeException(getMessage(TABLE_EXIST_FAILED, tableName), th);
        } finally {
            DbUtil.getInstance().closeResource(rs, null, conn);
        }
            
    }
    
    public void executeSqlFile(String fileName) {
        isValid(SQL_FILE, fileName);
        Connection conn = DbUtil.getInstance().getConnection();;
        PreparedStatement pstmt = null;
        InputStream in = null;
        try {
            in = ClassLoader.getSystemClassLoader().getResourceAsStream(fileName);
            String getAllQuery = new String(in.readAllBytes());
            
            for (String singleQuery : getAllQuery.split(";;")){
               pstmt = conn.prepareStatement(singleQuery);
               pstmt.executeUpdate();
            }            
        } catch(Throwable th) {
            throw new RuntimeException(getMessage(SQL_QUERY_FAILED, fileName), th);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Throwable th) {};
            }
            
            DbUtil.getInstance().closeResource(null, pstmt, conn);
        }
    }
    
    public void closeResource(ResultSet rs, PreparedStatement pstmt, Connection conn){
        if (rs != null) {
            try {
                rs.close();
            } catch(Throwable th) {}    
        }
        
        if (pstmt != null) {
            try{ 
                pstmt.close();
            } catch(Throwable th) {}
        }
        
        if (conn != null) {
            try {
                conn.close();
            } catch(Throwable th) {}    
        }
    }
    
    private static void isValid(String paramName, String paramvalue) {
        if(paramvalue == null || paramvalue.isEmpty()) {
            throw new RuntimeException(MessageFormat.format(INVALID_VALUE, paramName));
        }
    }
    
    private static String getMessage(String message, Object... values) {
        if (message == null || message.isEmpty()) {
            return INVALID_MESSAGE;
        }
        
        if (values == null || values.length == 0) {
            return message;
        } else {
            return MessageFormat.format(message, values);
        }
    }    
    
    private static final String CONNECTION_FAILED = "Failed to get new connection from {0}.";
    private static final String PROPERTIES_FAILED = "Failed to get configuration values from {0}.";
    
    private static final String INVALID_VALUE = "Invalid value for {0} name.";
    private static final String INVALID_MESSAGE = "Invalid message.";
    
    private static final String TABLE_EXIST_FAILED = "Failed to check table exist for {0}.";
    private static final String SQL_QUERY_FAILED = "Failed to execute sql query from {0}.";
}
