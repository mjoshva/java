package com.infinira.payroll.model;

import java.util.Date;
import java.text.MessageFormat;

public class Employee{
    private int id;
    private String firstName;
    private String lastName;
    private String fatherName;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String country;
    private String zipCode;
    private String gender;
    private Date dob;
    private String maritalStatus;
    private String phone;
    private String email;
    private String incomeTaxId;
    private String nationalId;
    private String bloodGroup;
    private Date doj;
    private byte[] photo;
    private EmployeeStatus status;
    private Date createdDate;
    private Date modifiedDate;
    
    private static final String FIRST_NAME = "first name";
    private static final String LAST_NAME = "last name";
    private static final String FATHER_NAME = "father name";
    
    private static final String ADDRESS_LINE1 = "address line1";
    private static final String ADDRESS_LINE2 = "address line2";
    private static final String CITY = "city";
    private static final String STATE = "state";
    private static final String COUNTRY = "country";
    private static final String ZIP_CODE = "zip code";
    
    private static final String GENDER = "gender";
    private static final String MARRITAL_STATUS = "marital status";
    private static final String PHONE = "phone";
    private static final String EMAIL = "email'";
    private static final String INCOME_TAX_ID = "income tax id";
    private static final String NATIONAL_ID = "national id";
    private static final String BLOOD_GROUP = "blood group";
    
    private static final int FIRST_NAME_MAX_LENGTH = 25;
    private static final int LAST_NAME_MAX_LENGTH = 25;
    private static final int FATHER_NAME_MAX_LENGTH = 50;
    
    private static final int ADDRESS1_MAX_LENGTH = 50;
    private static final int ADDRESS2_MAX_LENGTH = 50;
    private static final int CITY_MAX_LENGTH = 50;
    private static final int STATE_MAX_LENGTH = 50;
    private static final int COUNTRY_MAX_LENGTH = 50;
    private static final int ZIP_MAX_LENGTH = 10;
    
    private static final int GENDER_MAX_LENGTH = 1;
    private static final int MARRITAL_MAX_LENGTH = 1;
    private static final int PHONE_MAX_LENGTH = 20;
    private static final int EMAIL_MAX_LENGTH = 254;
    
    private static final int INCOME_TAX_MAX_LENGTH = 18;
    private static final int NATIONAL_ID_MAX_LENGTH = 20;
    private static final int BLOOD_GROUP_MAX_LENGTH = 3;
    
    public Employee(String firstName, String lastName, String incomeTaxId, String nationalId) {
        isValid(FIRST_NAME, firstName, FIRST_NAME_MAX_LENGTH);
        this.firstName = firstName;
        
        isValid(LAST_NAME, lastName, LAST_NAME_MAX_LENGTH);
        this.lastName = lastName;
        
        isValid(INCOME_TAX_ID, incomeTaxId, INCOME_TAX_MAX_LENGTH);
        this.incomeTaxId =  incomeTaxId;
        
        isValid(NATIONAL_ID, nationalId, NATIONAL_ID_MAX_LENGTH);
        this.nationalId = nationalId;
    }
    
    public Employee() {
    
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        isValid(FIRST_NAME, firstName, FIRST_NAME_MAX_LENGTH);
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        isValid(LAST_NAME, lastName, LAST_NAME_MAX_LENGTH);
        this.lastName = lastName;
    }
    
    public String getFatherName() {
        return fatherName;
    }
    
    public void setFatherName(String fatherName) {
        isValid(FATHER_NAME, fatherName, FATHER_NAME_MAX_LENGTH);
        this.fatherName = fatherName;
    }
    
    public String getAddressLine1() {
        return addressLine1;
    }
    
    public void setAddressLine1(String addressLine1) {
        isValid(ADDRESS_LINE1, addressLine1, ADDRESS1_MAX_LENGTH);
        this.addressLine1 = addressLine1;
    }
    
    public String getAddressLine2() {
        return addressLine2;
    }
    
    public void setAddressLine2(String addressLine2) {
        isValid(ADDRESS_LINE2, addressLine2, ADDRESS2_MAX_LENGTH);  
        this.addressLine2 = addressLine2;
    }
    
    public String getCity() {
        return city;
    }
    
    public void setCity(String city) {
        isValid(CITY, city, CITY_MAX_LENGTH);
        this.city = city;
    }
    
    public String getState() {
        return state;
    }
    
    public void setState(String state) {
        isValid(STATE, state, STATE_MAX_LENGTH);
        this.state = state;
    }
    
    public String getCountry() {
        return country;
    }
    
    public void setCountry(String country) {
        isValid(COUNTRY, country, COUNTRY_MAX_LENGTH);
        this.country = country;
    }
    
    public String getZipCode() {
        return zipCode;
    }
    
    public void setZipCode(String zipCode) {
        isValid(ZIP_CODE, zipCode, ZIP_MAX_LENGTH);
        this.zipCode = zipCode;
    }
    
    public String getGender() {
        return gender;
    }
    
    public void setGender(String gender) {
        isValid(GENDER, gender, GENDER_MAX_LENGTH);
        this.gender = gender;
    }
    
    public Date getDOB() {
        return dob;
    }
    
    public void setDOB(Date dob) {
        this.dob = dob;
    }
    
    public String getMaritalStatus() {
        return maritalStatus;
    }
    
    public void setMaritalStatus(String maritalStatus) {
        isValid(MARRITAL_STATUS, maritalStatus, MARRITAL_MAX_LENGTH);
        this.maritalStatus = maritalStatus;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        isValid(PHONE, phone, PHONE_MAX_LENGTH);
        this.phone = phone;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        isValid(EMAIL, email, EMAIL_MAX_LENGTH);
        this.email = email;
    }
    
    public String getIncomeTaxId() {
        return incomeTaxId;
    }
    
    public void setIncomeTaxId(String incomeTaxId) {
        isValid(INCOME_TAX_ID, incomeTaxId, INCOME_TAX_MAX_LENGTH);
        this.incomeTaxId = incomeTaxId;
    }
    
    public String getNationalId() {
        return nationalId;
    }
    
    public void setNationalId(String nationalId) {
        isValid(NATIONAL_ID, nationalId, NATIONAL_ID_MAX_LENGTH);
        this.nationalId = nationalId;
    }
    
    public String getBloodGroup() {
        return bloodGroup;
    }
    
    public void setBloodGroup(String bloodGroup) {
        isValid(BLOOD_GROUP, bloodGroup, BLOOD_GROUP_MAX_LENGTH);
        this.bloodGroup = bloodGroup;
    }   
    
    public Date getDOJ() {
        return doj;
    }
    
    public void setDOJ(Date doj) {
        this.doj = doj;
    }
    
    public byte[] getPhoto() {
        return photo;
    }
    
    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }
    
    public EmployeeStatus getStatus() {
        return status;
    }
    
    public void setStatus(EmployeeStatus status) {
        this.status = status;
    }
    
    public Date getCreatedDate() {
        return createdDate;
    }
    
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
    
    public Date getModifiedDate() {
        return modifiedDate;
    }
    
    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
    
    private static void isValid(String paramName, String paramValue, int maxLength) {
        if (paramValue == null || paramValue.isEmpty()) {
            throw new RuntimeException(MessageFormat.format(INVALID_FIELD, paramName));
        }
        
        if (paramValue.length() > maxLength) {
            throw new RuntimeException(MessageFormat.format(LENGTH_FAILED, paramName, paramValue, maxLength));
        }
    }
    
    private static final String LENGTH_FAILED = "Given {0} value is {1} is too long. please give {2} or below letters.";
    private static final String INVALID_FIELD = "Invalid value for {0}";
    
}