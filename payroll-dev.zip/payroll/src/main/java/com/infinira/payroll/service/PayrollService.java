package com.infinira.payroll.service;

import java.util.List;
import com.infinira.payroll.model.Employee;
import com.infinira.payroll.dao.EmployeeDao;

public class PayrollService implements PayrollInterface {
    
    public int createEmployee(Employee emp) {
        return EmployeeDao.create(emp);
    }
    
    public void updateEmployee(Employee emp) {
        EmployeeDao.update(emp);
    }
    
    public Employee getEmployeeById(int empId) {
        return EmployeeDao.get(empId);
    }
    
    public List<Employee> getAllEmployee() {
        return EmployeeDao.getAll();
    }
    
    public void deleteEmployee(int empId) {
        EmployeeDao.delete(empId);
    }
}