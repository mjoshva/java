package com.infinira.payroll.dao;

import com.infinira.payroll.util.DbUtil;
import com.infinira.payroll.util.ResourceUtil;
import com.infinira.payroll.util.PayrollException;
import com.infinira.payroll.model.Employee;
import com.infinira.payroll.model.EmployeeStatus;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
import java.sql.Types;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

public class EmployeeDao {
    
    public static int create(Employee emp) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DbUtil.getInstance().getConnection();
            pstmt = conn.prepareStatement(CREATE_EMPLOYEE, Statement.RETURN_GENERATED_KEYS);
            setQueryData(pstmt, emp);
            pstmt.executeUpdate();
            
            rs = pstmt.getGeneratedKeys();
            if (!rs.next()) {
                throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00004", emp.getFirstName()));
            } else {
                return rs.getInt(1);
            }
        } catch(Throwable th) {
            throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00003", emp.getFirstName()), th);
        } finally {
            DbUtil.getInstance().closeResource(rs, pstmt, conn);
        }
    }
        
    public static void update(Employee emp) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DbUtil.getInstance().getConnection();
            pstmt = conn.prepareStatement(UPDATE_EMPLOYEE);
            setQueryData(pstmt, emp);

            if (pstmt.executeUpdate() == 0) {
                throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00009", emp.getId()));
            }   
        } catch(Throwable th) {
            throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00005", emp.getId()), th);
        } finally {
            DbUtil.getInstance().closeResource(null, pstmt, conn);
        }
    }
    
    public static Employee get(int empId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DbUtil.getInstance().getConnection();
            pstmt = conn.prepareStatement(GET_EMPLOYEE);
            pstmt.setInt(1, empId);
            rs = pstmt.executeQuery();
            
            if (rs.next() == false) {
                throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00009", empId));
            } else {
                return getResultData(rs);
            }
        } catch(Throwable th) {
            throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00006", empId), th);
        } finally {
            DbUtil.getInstance().closeResource(rs, pstmt, conn);
        }
    }

    public static List<Employee> getAll() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DbUtil.getInstance().getConnection();
            pstmt = conn.prepareStatement(GET_ALL_EMPLOYEE);
            rs = pstmt.executeQuery();
            
            List<Employee> empList = new ArrayList<Employee>();
            
            while(rs.next()) {
                empList.add(getResultData(rs));
            }
            
            return empList;
        } catch(Throwable th) {
            throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00007"), th);
        } finally {
            DbUtil.getInstance().closeResource(rs, pstmt, conn);
        }
    }

    public static void delete(int empId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DbUtil.getInstance().getConnection();
            pstmt = conn.prepareStatement(DELETE_EMPLOYEE);
            pstmt.setInt(1, empId);
            
            if (pstmt.executeUpdate() == 0) {
                throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00009", empId));
            }
        } catch(Throwable th) {
            throw new PayrollException(ResourceUtil.getInstance().getMessage("PR-00008", empId), th);
        } finally {
            DbUtil.getInstance().closeResource(null, pstmt, conn);
        }
    }
    
    private static void setQueryData(PreparedStatement pstmt ,Employee emp) throws SQLException{
        int i = 0;
        pstmt.setString(++i, emp.getFirstName());
        pstmt.setString(++i, emp.getLastName());    
        pstmt.setString(++i, emp.getFatherName());
        
        pstmt.setString(++i, emp.getAddressLine1());
        pstmt.setString(++i, emp.getAddressLine2());
        pstmt.setString(++i, emp.getCity());
        pstmt.setString(++i, emp.getState());
        pstmt.setString(++i, emp.getCountry());
        pstmt.setString(++i, emp.getZipCode());
        
        pstmt.setString(++i, emp.getGender());
        pstmt.setDate(++i, new Date(emp.getDOB().getTime()));
        pstmt.setString(++i, emp.getMaritalStatus());
        pstmt.setString(++i, emp.getPhone());
        pstmt.setString(++i, emp.getEmail());
        
        pstmt.setString(++i, emp.getIncomeTaxId());
        pstmt.setString(++i, emp.getNationalId());
        
        pstmt.setString(++i, emp.getBloodGroup());
        
        pstmt.setDate(++i, new Date(emp.getDOJ().getTime()));
        pstmt.setBytes(++i, emp.getPhoto());
        
        pstmt.setObject(++i, emp.getStatus(), Types.OTHER);
        
        if (emp.getId() > 0) {
            pstmt.setInt(++i, emp.getId());
        }           
    }
    
    private static Employee getResultData(ResultSet rs) throws SQLException{
        Employee emp = new Employee();
        
        int i = 0;
        emp.setId(rs.getInt(++i));
        emp.setFirstName(rs.getString(++i));
        emp.setLastName(rs.getString(++i));
        emp.setFatherName(rs.getString(++i));
        
        emp.setAddressLine1(rs.getString(++i));
        emp.setAddressLine2(rs.getString(++i));
        emp.setCity(rs.getString(++i));
        emp.setState(rs.getString(++i));
        emp.setCountry(rs.getString(++i));
        emp.setZipCode(rs.getString(++i));
        
        emp.setGender(rs.getString(++i));
        emp.setDOB(rs.getDate(++i));
        emp.setMaritalStatus(rs.getString(++i));
        emp.setPhone(rs.getString(++i));
        emp.setEmail(rs.getString(++i));
    
        emp.setIncomeTaxId(rs.getString(++i));
        emp.setNationalId(rs.getString(i++));
        
        emp.setBloodGroup(rs.getString(++i));   
        
        emp.setDOJ(rs.getDate(++i));
        emp.setPhoto(rs.getBytes(++i));
        
        emp.setStatus(EmployeeStatus.valueOf(rs.getString(++i)));
        emp.setCreatedDate(rs.getDate(++i));
        emp.setModifiedDate(rs.getDate(++i));
        
        return emp;
    }

    private static final String CREATE_EMPLOYEE = "INSERT INTO employee(first_name, last_name, father_name, address_line1, address_line2, city, state, country, zip_code, gender, dob, marital_status, phone, email_id, income_tax_id, national_id, blood_group, doj, photo, status) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String GET_ALL_EMPLOYEE = "SELECT id, first_name, last_name, father_name, address_line1, address_line2, city, state, country, zip_code, gender, dob, marital_status, phone, email_id, income_tax_id, national_id, blood_group, doj, photo, status, created_date, modified_date, photo FROM employee";
    
    private static final String GET_EMPLOYEE = "SELECT id, first_name, last_name, father_name, address_line1, address_line2, city, state, country, zip_code, gender, dob, marital_status, phone, email_id, income_tax_id, national_id, blood_group, doj, photo, status, created_date, modified_date, photo FROM employee WHERE id = ?";
    
    private static final String UPDATE_EMPLOYEE = "UPDATE employee SET first_name = ?, last_name = ?, father_name = ?, address_line1 = ?, address_line2 = ?, city = ?, state = ?, country = ?, zip_code = ?, gender = ?, dob = ?, marital_status = ?, phone = ?, email_id = ?, income_tax_id = ?, national_id = ?, blood_group = ?, doj = ?, photo = ?, status = ?, modified_date = CURRENT_DATE WHERE id = ?";
    
    private static final String DELETE_EMPLOYEE = "DELETE FROM employee WHERE id = ?";

}