package com.infinira.payroll.model;

public enum EmployeeStatus{
    ACTIVE, 
    RETIRED,
    SUSPENDED,
    TERMINATED,
    FURLOUGH,
    DORMANT,
    RESIGNED
}