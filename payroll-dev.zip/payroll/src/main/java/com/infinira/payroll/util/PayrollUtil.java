package com.infinira.payroll.util;

public class PayrollUtil {
    private static final String EMP_TABLE_NAME = "employee";
    private static final String SQL_FILE_NAME = "payrollCreateSchema.sql";
   
    public static void createSchema() {
        if(DbUtil.getInstance().isTableExist(EMP_TABLE_NAME) == false){
            DbUtil.getInstance().executeSqlFile(SQL_FILE_NAME);
        }
        
    }
}
