package com.infinira.payroll.util;

import java.util.Locale;
import java.util.ResourceBundle;
import java.text.MessageFormat;

public class ResourceUtil {
    public static volatile ResourceUtil instance = null;
    
    ResourceBundle resBundle;
    private static final String RESOURCE_BUNDLE = "PayrollMessage";
    
    private ResourceUtil() {
        init();
    }
    
    private void init() {
        try {
            Locale locale = Locale.getDefault();
            resBundle = ResourceBundle.getBundle(RESOURCE_BUNDLE, locale);
        } catch (Throwable th) {
            throw new RuntimeException("Failed to set resource bundle from " + RESOURCE_BUNDLE, th);
        }
    }
    
    public static ResourceUtil getInstance() {
        if (instance == null) {
            synchronized(ResourceUtil.class) {
                if(instance == null) {
                    instance = new ResourceUtil();
                }
            }
        }
        return instance;
    }
    
    public String getMessage(String key, Object... values) {
        if (key == null || key.isEmpty()) {
            return "Invalid key";
        }
        
        if (!resBundle.containsKey(key)) {
            return "Invalid key: " + key;
        }
        
        if (resBundle.getString(key).length() == 0) {
            return "Invalid message for key: " + key;
        }
        
        if (values == null || values.length == 0) {
            return resBundle.getString(key);
        } else {
            return MessageFormat.format(resBundle.getString(key), values);
        }
    }
}